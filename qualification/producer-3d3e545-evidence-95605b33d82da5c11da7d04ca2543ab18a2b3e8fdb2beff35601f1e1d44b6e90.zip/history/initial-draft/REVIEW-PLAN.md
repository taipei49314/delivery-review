# Pending producer qualification dossier

Status: **pending**. No producer is admitted by this dossier, no registry entry is
created, and no complete-product E01 claim is made.

The candidate is `taipei49314/delivery-review` (repository ID 1438021135), exact
commit `3d3e54599066c98f52384c66953b130a01eaaff8`. Review the two fixed workflow
paths separately: `.github/workflows/pytest-producer.yml` for `pr_head`, and
`.github/workflows/pytest-producer-merge.yml` for `github_merge`. Both use
`pytest-isolated-container-v1`, literal test path `tests`, and pytest 8.4.2 xunit2.
The committed producer sources, dependency hashes and all four action pins are
included without normalization. Host Python is configured as 3.11.16; the
remaining hosted boundary measurements must establish the guest runtime and
isolation properties before a runtime qualification receipt is authored.

## Original public controls already inventoried

| Control | PR | Run | Job/check | Artifact |
| --- | --- | --- | --- | --- |
| Head positive | 4 | 42183133333 | 127777123008 | 13486795225 |
| Zero tests | 5 | 42183520665 | 127778362228 | 13486193789 |
| All skipped | 6 | 42183525284 | 127778376129 | 13486726129 |
| Test failure | 7 | 42183526273 | 127778380265 | 13485933125 |
| Merge positive | 8 | 42183531120 | 127778394701 | 13486008687 |
| Collection error | 9 | 42184514877 | 127781584267 | 13486752617 |
| One pass plus one skip | 10 | 42184515614 | 127781587133 | 13487245553 |

`draft.json` records exact base/head/checkout identities, ordered merge parents,
native exits, job conclusions, counts and receipt/JUnit/ZIP/bundle hashes. These
are original observations, not a claim that every variant has independently
passed cryptographic and execution-boundary review. Original public repository
responses establish `private: false` for the reference and producer repositories.
API capture hashes and original artifact inventories were independently checked
while preparing this draft.

The head and merge positive artifacts were independently reverified with the
installed, qualified 3d3 product, official native Python 3.11.16 and pinned
`gh` 2.98.0. A real network namespace had only loopback, no routes and returned
`ENETUNREACH` on an external connection probe. All 17 planned expectations
matched: two positive signatures, six official-verifier rejections, eight
cryptographically valid signatures rejected for authored expectation mismatches,
and one explicitly controller-only digest refusal. Original envelopes stayed
unchanged. Native exit codes and adapter dispositions remain separate in the
retained result. The negative identities are authored controls, not claims of
observed malicious GitHub executions.

## Remaining admission work

1. Review actual hosted boundary controls for both source modes at this exact
   producer revision: runtime, UID/GID, network and credential absence, dropped
   capabilities, privilege/seccomp checks, read-only host mounts, cgroup limits,
   bounded tmpfs and confirmed stop/cleanup. Successful ordinary tests alone do
   not establish these properties.
2. Preserve and review the actual forgery/background, symlink-report, abrupt
   exit, output-limit, timeout and disk-limit controls. Distinguish a correctly
   refused measurement from a signed complete test failure. Retain failed and
   unavailable attempts rather than replacing their outcomes.
3. Review two separate caller attacks: precreated mapped artifact name; and a
   newly created control run whose original ZIP is preserved, deleted, then
   reuploaded byte-identically under the same name with a new artifact ID. Do
   not mutate positive PR4/PR8 artifacts. Bind rejection to original platform
   metadata and signed artifact identity, not only names or ZIP hashes.
4. Independently verify every additional signed variant with the pinned official
   verifier and original source/run/job/artifact expectations. The five nonpositive
   functional variants above currently retain bundles but are not credited by
   this dossier's two-positive cryptographic receipt.
5. Review boundary receipts, action/source/runtime pins and public export
   omissions. Then author separate exact-path/source-mode qualification receipts
   only if all required observations support admission. Any product-code changes
   require their own immutable candidate qualification.
6. Registry admission, a new complete-product inspection, blocked-network
   positive replay and E01/E03 acceptance are subsequent operations. This pending
   dossier cannot retroactively upgrade any earlier inspection.

The current boundary/attacker fixture preparation and execution are owned by the
producer task; receipt IDs will be added only after actual capture. Earlier runs
42177088855, 42178476087 and 42181483713 remain separately retained failures at
earlier revisions and are not recast as successful 3d3 proof.

## Compact immutable public evidence export plan

`public-export-candidate/` is a local review candidate, currently 369 files and
2,254,764 bytes. `evidence-inventory.json` lists each original source path,
destination, size, SHA-256 and provenance. The candidate contains:

- Original public API bodies and capture metadata for each listed run.
- Original artifact list/detail responses, downloaded ZIPs and exact extracted
  receipt/JUnit members, original compressed attestation bundle bytes and their
  response content types. A `.json` suffix does not imply the original transport
  bytes were uncompressed JSON.
- Safe discovery omission records with original body hash/size and locator hash.
  Credential-bearing transient discovery bodies and signed storage URLs were
  never retained and must not be reconstructed for publication.
- Exact committed producer/workflow source bytes and pins.
- Original official-verifier inputs, outputs, manifests and observations, plus
  the explicitly authored negative-case plan and namespace evidence.

Keep original bytes unchanged. Public job logs remain local, identified by hash
in the omission list; derived public-API diagnostics that substituted states or
inferred OIDC are excluded from the export. Private EC and Pinwash observations
are outside this source inventory. A bounded content-pattern scan found no
credential/private-source/transient-locator matches; it is an additional review
aid, not a guarantee or a substitute for the source allowlist.

After remaining controls are captured, create a new versioned export inventory
and deterministic archive with a published SHA-256, rather than rewriting this
draft's originals. Include this pending/status history and explicit omission
index. Publish only the reviewed export, anchored to the exact product and
fixture revisions, so users can reproduce official cryptography without GitHub
credentials or expiring artifact URLs. No publication occurs in this task.
