"""Read-only original public proof review with real pinned offline cryptography."""
from datetime import datetime, timezone
import errno
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile

MAIN = Path('/mnt/c/Users/play/Documents/Codex/2026-11-06/new-chat-2/work/delivery-review')
OUT = MAIN / 'work/producer-qualification-3d3e545-draft/signed-controls-review-01'
PYTHON = Path('/tmp/delivery-review-full-qualification-_qdo_n2e/installed-environment/bin/python')
TOOLS = Path('/tmp/delivery-review-public-reference-3d3e545-5avrzwcm/tools')
PRODUCT = '3d3e54599066c98f52384c66953b130a01eaaff8'
REPO = 'taipei49314/delivery-review-reference'
ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}
CONTROLS = [('head', 4, 42183133333, 127777123008, 13486795225),
    ('zero_tests', 5, 42183520665, 127778362228, 13486193789),
    ('all_skipped', 6, 42183525284, 127778376129, 13486726129),
    ('test_failure', 7, 42183526273, 127778380265, 13485933125),
    ('merge', 8, 42183531120, 127778394701, 13486008687),
    ('collection_error', 9, 42184514877, 127781584267, 13486752617),
    ('partial_skip', 10, 42184515614, 127781587133, 13487245553),
    ('boundary_head', 11, 42185117504, 127783516251, 13487291155),
    ('boundary_merge', 12, 42185121657, 127783529715, 13487331336),
    ('disk_limit', 18, 42185140279, 127783590468, 13487325899)]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(root, name, value):
    with (root / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def load(path):
    return json.loads(path.read_bytes())

def tree(root):
    return [{'path': p.relative_to(root).as_posix(), 'sha256': sha(p.read_bytes()), 'size_bytes': p.stat().st_size}
            for p in sorted(root.rglob('*')) if p.is_file()]

if '--inside' not in sys.argv:
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'review-script.py')
    argv = ['unshare', '--net', str(PYTHON), '-I', str(Path(__file__).resolve()), '--inside']
    result = subprocess.run(argv, env=ENV, capture_output=True, timeout=240)
    (OUT / 'namespace.stdout').write_bytes(result.stdout)
    (OUT / 'namespace.stderr').write_bytes(result.stderr)
    save(OUT, 'namespace-launch.json', {'argv': argv, 'exit_code': result.returncode,
        'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
    print(result.stdout.decode(errors='replace'))
    print(result.stderr.decode(errors='replace'))
    raise SystemExit(result.returncode)

from delivery_review.adapters import github_attestation as attest
from delivery_review.adapters.artifact_zip import read_artifact_zip
from delivery_review.adapters.bundle_encoding import decode_bundle_body, DECODER_VERSION
from delivery_review.adapters.pytest_junit import parse_pytest_junit
from delivery_review.provenance import collector_identity
from delivery_review.test_evidence import RawApiFact, merge_reference_identity

assert collector_identity()['source_sha'] == PRODUCT
assert socket.if_nameindex() == [(1, 'lo')]
routes = Path('/proc/net/route').read_text().splitlines()
assert not routes or len(routes) == 1 and routes[0].startswith('Iface')
try:
    with socket.create_connection(('192.0.2.1', 443), timeout=1):
        raise AssertionError('External route unexpectedly reachable')
except OSError as exc:
    assert exc.errno == errno.ENETUNREACH
    network = {'namespace': os.readlink('/proc/self/ns/net'), 'interfaces': socket.if_nameindex(),
        'routes': routes, 'probe_address': '192.0.2.1:443', 'probe_errno': exc.errno}
save(OUT, 'network-isolation.json', network)
native = Path(tempfile.mkdtemp(prefix='delivery-review-producer-signed-controls-3d3-'))
tool_config = load(TOOLS / 'toolchain.json')
gh = (TOOLS / tool_config['gh_executable']).resolve(strict=True)
root = (TOOLS / tool_config['trusted_root']).read_bytes() if 'trusted_root' in tool_config else (TOOLS / 'trusted-root.jsonl').read_bytes()
assert sha(gh.read_bytes()) == attest.GH_PINS[('linux', 'amd64')]
assert sha(root) == '65ca537f6ed8a47fd0e560c421baa1f6c1efb8b25fc200d8c5c02c0e92eb2b9c'
save(OUT, 'context.json', {'scope': 'Actual public original signature and raw count review; pending producer qualification.',
    'collector': collector_identity(), 'python': sys.version, 'base_prefix': sys.base_prefix,
    'adapter_sha256': sha(Path(attest.__file__).read_bytes()), 'network': network, 'native': str(native),
    'gh_sha256': sha(gh.read_bytes()), 'trusted_root_sha256': sha(root), 'no_credentials': True,
    'source_expectation_basis': 'Original fixed-route merge reference for certificate event identity; original receipt/source reviewed separately.',
    'registry_changed': False, 'qualified': False})
save(OUT, 'case-plan.json', [{'control': c, 'pr_number': p, 'run_id': r, 'job_id': j, 'artifact_id': a,
    'expected': 'official signature accepted for exact original platform identities; no producer qualification granted'}
    for c, p, r, j, a in CONTROLS])
results = []
try:
    for label, pr_number, run_id, job_id, artifact_id in CONTROLS:
        destination = OUT / label
        destination.mkdir()
        source = MAIN / 'work/hosted-reference' / ('run-' + str(run_id))
        api_dirs, evidence_dirs = list(source.glob('public-api-*')), list(source.glob('original-evidence-*'))
        assert len(api_dirs) == len(evidence_dirs) == 1
        api, evidence = api_dirs[0], evidence_dirs[0]
        before = tree(source)
        save(destination, 'original-tree-before.json', before)
        captures = load(api / 'capture.json')
        by_label = {r['label']: r for r in captures}
        assert len(by_label) == len(captures)
        for record in captures:
            assert record['status_code'] == 200 and record['complete'] and record['error'] is None
            assert sha((api / (record['label'] + '.json')).read_bytes()) == record['sha256']
        for record in load(evidence / 'inventory.json'):
            raw = (evidence / record['path']).read_bytes()
            assert sha(raw) == record['sha256'] and len(raw) == record['size_bytes']
        repo, producer_repo, pr, run, attempt, check = [load(api / (n + '.json')) for n in
            ('repository', 'producer_repository', 'pull_request', 'run', 'attempt', 'check')]
        assert repo['private'] is producer_repo['private'] is False
        assert repo['id'] == 1447925554 and producer_repo['id'] == 1438021135
        assert repo['full_name'] == REPO and producer_repo['full_name'] == 'taipei49314/delivery-review'
        assert pr['number'] == pr_number and run['id'] == attempt['id'] == run_id
        assert run['run_attempt'] == attempt['run_attempt'] == 1 and run['event'] == 'pull_request'
        jobs = load(api / 'jobs.json')
        assert jobs['total_count'] == len(jobs['jobs']) == 1
        job = jobs['jobs'][0]
        assert job['id'] == job_id and job['run_id'] == run_id and job['run_attempt'] == 1
        assert job['head_sha'] == run['head_sha'] == pr['head']['sha']
        assert job['check_run_url'] == f'https://api.github.com/repos/{REPO}/check-runs/{check["id"]}'
        assert check['app']['id'] == 15368 and check['head_sha'] == pr['head']['sha']
        ref = by_label['merge_ref']
        event_sha = merge_reference_identity(RawApiFact(ref['path'], ref['status_code'],
            (api / 'merge_ref.json').read_bytes(), ref['observed_at'], ref['complete'], ref['response_headers']), REPO, pr_number)
        artifact, receipt_raw, junit = [(evidence / (str(artifact_id) + suffix)).read_bytes()
            for suffix in ('.zip', '-receipt.json', '-junit.xml')]
        meta, receipt = load(evidence / (str(artifact_id) + '.json')), json.loads(receipt_raw)
        listing = load(api / 'artifacts.json')
        assert listing['total_count'] == len(listing['artifacts']) == 1
        assert listing['artifacts'][0] == meta
        assert meta['id'] == artifact_id and meta['name'] == f'delivery-review-{run_id}-1-{job_id}'
        assert meta['expired'] is False and meta['digest'] == 'sha256:' + sha(artifact) and meta['size_in_bytes'] == len(artifact)
        assert meta['workflow_run']['id'] == run_id and meta['workflow_run']['head_sha'] == pr['head']['sha']
        assert meta['workflow_run']['repository_id'] == meta['workflow_run']['head_repository_id'] == repo['id']
        archive = read_artifact_zip(artifact, policy_limits={'artifact_bytes': 25*1024*1024,
            'expanded_bytes': 100*1024*1024, 'archive_members': 100})
        assert dict(archive.files) == {'receipt.json': receipt_raw, 'junit.xml': junit}
        producer = receipt['producer']
        assert producer['workflow_sha'] == PRODUCT and producer['run_id'] == run_id and producer['job_id'] == job_id
        assert producer['attempt'] == 1 and producer['repository_id'] == producer_repo['id']
        refs = [v for v in attempt['referenced_workflows'] if v['path'] ==
            producer_repo['full_name'] + '/' + producer['workflow_path'] + '@' + PRODUCT]
        assert len(refs) == 1 and refs[0]['sha'] == PRODUCT
        assert receipt['repository_id'] == receipt['head_repository_id'] == repo['id'] and receipt['pr_number'] == pr_number
        assert receipt['source']['base_tip_sha'] == pr['base']['sha'] and receipt['source']['head_sha'] == pr['head']['sha']
        if receipt['source']['mode'] == 'pr_head':
            assert receipt['source']['checked_out_sha'] == pr['head']['sha'] and receipt['source']['merge_parents'] == []
        else:
            assert receipt['source']['mode'] == 'github_merge' and receipt['source']['checked_out_sha'] == event_sha
            assert receipt['source']['merge_parents'] == [pr['base']['sha'], pr['head']['sha']]
        assert receipt['execution']['junit']['sha256'] == sha(junit) and receipt['execution']['junit']['size_bytes'] == len(junit)
        parsed = parse_pytest_junit(junit)
        assert parsed['valid']
        counts = parsed['case_counts']
        assert receipt['execution']['tests'] == {'passed': counts['passed'], 'failed': counts['failures'],
            'errors': counts['errors'], 'skipped': counts['skipped']}
        discovery = load(evidence / (str(artifact_id) + '-attestation-capture.json'))
        assert discovery['next_cursor'] is None and discovery['discovery']['status_code'] == 200
        assert discovery['discovery']['body_complete'] and discovery['discovery']['error'] is None
        assert len(discovery['bundles']) == 1
        bundle_meta = discovery['bundles'][0]
        assert bundle_meta['repository_id'] == repo['id'] and bundle_meta['response']['status_code'] == 200
        assert bundle_meta['response']['complete'] and bundle_meta['response']['error'] is None
        compressed = (evidence / bundle_meta['body_file']).read_bytes()
        assert sha(compressed) == bundle_meta['body_sha256']
        content_type = bundle_meta['response']['response_headers'].get('content-type')
        bundle = decode_bundle_body(compressed, content_type)
        (destination / 'original-transport-bundle.bin').write_bytes(compressed)
        expected = {'repository_id': repo['id'], 'repository_full_name': REPO, 'certificate_source_sha': event_sha,
            'certificate_event': 'pull_request', 'run_id': run_id, 'run_attempt': 1,
            'producer_repository_full_name': producer_repo['full_name'], 'producer_path': producer['workflow_path'],
            'producer_sha': PRODUCT, 'job_id': job_id, 'check_run_id': check['id'], 'artifact_id': artifact_id,
            'artifact_sha256': sha(artifact), 'receipt_sha256': sha(receipt_raw), 'junit_sha256': sha(junit)}
        execution = attest.verify_github_attestation(artifact_bytes=artifact, bundle_bytes=bundle, trusted_root_bytes=root,
            gh_executable=gh, gh_sha256=attest.GH_PINS[('linux', 'amd64')], expected=expected,
            destination=native / label, limits=attest.AttestationLimits(timeout_seconds=20))
        (destination / 'verification.json').write_bytes(execution.manifest_bytes)
        (destination / 'observation.json').write_bytes(execution.observation_bytes)
        for key, raw in execution.raw_files.items():
            (destination / (key + '.bin')).write_bytes(raw)
        save(destination, 'parsed-junit.json', parsed)
        after = tree(source)
        save(destination, 'original-tree-after.json', after)
        assert before == after
        row = {'control': label, 'pr_number': pr_number, 'run_id': run_id, 'job_id': job_id, 'artifact_id': artifact_id,
            'source_path': str(source), 'source_mode': receipt['source']['mode'], 'original_source': receipt['source'],
            'job_conclusion': job['conclusion'], 'native_test_exit': receipt['execution']['test_exit'],
            'counts': receipt['execution']['tests'], 'junit_reason_codes': parsed['reason_codes'],
            'native_verifier_exit': execution.manifest['process']['exit_code'],
            'adapter_status': execution.observation['status'], 'cryptographic_verification': execution.observation['cryptographic_verification'],
            'reason_codes': execution.observation['reason_codes'], 'artifact_sha256': sha(artifact), 'receipt_sha256': sha(receipt_raw),
            'junit_sha256': sha(junit), 'transport_bundle_sha256': sha(compressed), 'decoded_bundle_sha256': sha(bundle),
            'content_type': content_type, 'decoder_version': DECODER_VERSION, 'originals_unchanged': True,
            'qualified': False, 'registry_changed': False}
        save(destination, 'result.json', row)
        results.append(row)
        print(label, row['native_verifier_exit'], row['adapter_status'], flush=True)
    assert all(r['native_verifier_exit'] == 0 and r['adapter_status'] == 'verified_claims' for r in results)
    save(OUT, 'result.json', {'status': 'completed', 'qualification_status': 'pending', 'qualified': False,
        'created_at': datetime.now(timezone.utc).isoformat(), 'product_sha': PRODUCT, 'network': network,
        'cases': results, 'all_original_signatures_verified': True, 'registry_changed': False,
        'limitations': ['Does not by itself establish producer execution isolation, complete product behavior or registry admission.',
            'Source-mode assertions are original signed receipt declarations reconciled to platform PR/ref inputs, not independent checkout execution proof.']})
except BaseException as exc:
    save(OUT, 'failure.json', {'type': type(exc).__name__, 'message': str(exc), 'completed_results': results})
    raise
