"""Independent raw lifecycle review and actual pinned offline identity checks."""
from copy import deepcopy
from datetime import datetime, timezone
import errno
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile

MAIN = Path('/mnt/c/Users/play/Documents/Codex/2026-11-06/new-chat-2/work/delivery-review')
OUT = MAIN / 'work/producer-qualification-3d3e545-draft/artifact-attack-review-01'
PYTHON = Path('/tmp/delivery-review-full-qualification-_qdo_n2e/installed-environment/bin/python')
TOOLS = Path('/tmp/delivery-review-public-reference-3d3e545-5avrzwcm/tools')
PRODUCT = '3d3e54599066c98f52384c66953b130a01eaaff8'
REPO = 'taipei49314/delivery-review-reference'
ENV = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}
API_NAMES = {'capture.json', 'repository.json', 'producer_repository.json', 'pull_request.json',
             'run.json', 'attempt.json', 'jobs.json', 'check.json', 'merge_ref.json', 'artifacts.json'}

def sha(raw): return hashlib.sha256(raw).hexdigest()
def load(path): return json.loads(path.read_bytes())
def save(path, value):
    with path.open('x') as stream: stream.write(json.dumps(value, indent=2) + '\n')
def tree(path):
    return [{'path': p.relative_to(path).as_posix(), 'sha256': sha(p.read_bytes()), 'size_bytes': p.stat().st_size}
            for p in sorted(path.rglob('*')) if p.is_file()]

if '--inside' not in sys.argv:
    OUT.mkdir()
    shutil.copyfile(__file__, OUT / 'review-script.py')
    argv = ['unshare', '--net', str(PYTHON), '-I', str(Path(__file__).resolve()), '--inside']
    result = subprocess.run(argv, env=ENV, capture_output=True, timeout=180)
    (OUT / 'namespace.stdout').write_bytes(result.stdout)
    (OUT / 'namespace.stderr').write_bytes(result.stderr)
    save(OUT / 'namespace-launch.json', {'argv': argv, 'exit_code': result.returncode,
         'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
    print(result.stdout.decode(errors='replace')); print(result.stderr.decode(errors='replace'))
    raise SystemExit(result.returncode)

from delivery_review.adapters import github_attestation as attest
from delivery_review.adapters.artifact_zip import read_artifact_zip
from delivery_review.adapters.bundle_encoding import decode_bundle_body, DECODER_VERSION
from delivery_review.provenance import collector_identity
from delivery_review.test_evidence import RawApiFact, merge_reference_identity
assert collector_identity()['source_sha'] == PRODUCT
assert socket.if_nameindex() == [(1, 'lo')]
routes = Path('/proc/net/route').read_text().splitlines()
assert not routes or len(routes) == 1 and routes[0].startswith('Iface')
try:
    socket.create_connection(('192.0.2.1', 443), timeout=1)
    raise AssertionError('Unexpected external route')
except OSError as exc:
    assert exc.errno == errno.ENETUNREACH
    network = {'namespace': os.readlink('/proc/self/ns/net'), 'interfaces': socket.if_nameindex(), 'routes': routes,
               'external_probe': '192.0.2.1:443', 'errno': exc.errno}
save(OUT / 'network-isolation.json', network)
native = Path(tempfile.mkdtemp(prefix='delivery-review-artifact-attacks-3d3-'))
gh = (TOOLS / load(TOOLS / 'toolchain.json')['gh_executable']).resolve(strict=True)
root = (TOOLS / 'trusted-root.jsonl').read_bytes()
assert sha(gh.read_bytes()) == attest.GH_PINS[('linux', 'amd64')]
assert sha(root) == '65ca537f6ed8a47fd0e560c421baa1f6c1efb8b25fc200d8c5c02c0e92eb2b9c'
export = OUT / 'public-export-addition'; export.mkdir()
inventory, omissions, results = [], [], []
def copy(path, name):
    raw = path.read_bytes(); target = export / name; target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream: stream.write(raw)
    inventory.append({'source_path': path.relative_to(MAIN).as_posix(), 'path': name, 'sha256': sha(raw), 'size_bytes': len(raw)})
def archive(raw):
    return read_artifact_zip(raw, policy_limits={'artifact_bytes': 25*1024*1024, 'expanded_bytes': 100*1024*1024, 'archive_members': 100})
def verify(name, artifact, bundle, expected, positive):
    output = OUT / name; output.mkdir()
    value = attest.verify_github_attestation(artifact_bytes=artifact, bundle_bytes=bundle, trusted_root_bytes=root,
        gh_executable=gh, gh_sha256=attest.GH_PINS[('linux', 'amd64')], expected=expected,
        destination=native / name, limits=attest.AttestationLimits(timeout_seconds=20))
    (output / 'verification.json').write_bytes(value.manifest_bytes)
    (output / 'observation.json').write_bytes(value.observation_bytes)
    for key, raw in value.raw_files.items(): (output / (key + '.bin')).write_bytes(raw)
    row = {'control': name, 'expected': 'verified original identity' if positive else 'refused replacement identity',
           'native_exit': value.manifest['process']['exit_code'], 'adapter_status': value.observation['status'],
           'cryptographic_verification': value.observation['cryptographic_verification'], 'reason_codes': value.observation['reason_codes'],
           'artifact_id': expected['artifact_id'], 'artifact_sha256': sha(artifact), 'qualified': False}
    assert row['native_exit'] == 0 and row['cryptographic_verification'] == 'verified'
    assert (row['adapter_status'] == 'verified_claims') == positive
    if not positive: assert set(row['reason_codes']) == {'signed_predicate_mismatch', 'signed_subject_mismatch'}
    save(output / 'result.json', row); results.append(row); print(name, row['native_exit'], row['adapter_status'], flush=True)

save(OUT / 'case-plan.json', [{'control': 'deleted-original-identity', 'expected': 'official gh 0, verified original signature; historical only'},
     {'control': 'replacement-new-identity', 'expected': 'official gh 0, product rejects changed artifact ID despite identical ZIP'},
     {'control': 'ambiguous-genuine-member', 'expected': 'official gh 0, genuine signature valid in isolation; no selection credit among duplicates'}])
reviews = []
try:
    for label, pr_number, run_id, job_id, artifact_id in [('replacement', 19, 42186018027, 127786417057, 13487367915),
            ('precreation', 20, 42186022093, 127786429695, 13487253094)]:
        source = MAIN / 'work/hosted-reference' / f'run-{run_id}'
        before = tree(source)
        api = next(source.glob('public-api-*'))
        evidence = source / 'original-attack-evidence-1793953035734805900'
        for row in load(evidence / 'inventory.json'):
            raw = (evidence / row['path']).read_bytes()
            assert sha(raw) == row['sha256'] and len(raw) == row['size_bytes']
        captures = load(api / 'capture.json'); by_label = {r['label']: r for r in captures}
        for row in captures:
            assert row['status_code'] == 200 and row['complete'] and row['error'] is None
            assert sha((api / (row['label'] + '.json')).read_bytes()) == row['sha256']
        repo, producer_repo, pr, run, attempt, check = [load(api / (n + '.json')) for n in
            ('repository', 'producer_repository', 'pull_request', 'run', 'attempt', 'check')]
        assert repo['private'] is producer_repo['private'] is False
        assert repo['id'] == 1447925554 and producer_repo['id'] == 1438021135
        assert pr['number'] == pr_number and run['id'] == attempt['id'] == run_id and run['run_attempt'] == attempt['run_attempt'] == 1
        jobs = load(api / 'jobs.json')
        assert jobs['total_count'] == len(jobs['jobs']) == 2
        job = next(x for x in jobs['jobs'] if x['id'] == job_id)
        assert job['run_id'] == run_id and job['run_attempt'] == 1 and job['head_sha'] == pr['head']['sha']
        assert check['id'] == job_id and check['app']['id'] == 15368 and check['conclusion'] == job['conclusion'] == 'success'
        ref = by_label['merge_ref']; stamp = datetime.fromisoformat(ref['observed_at']).astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        event_sha = merge_reference_identity(RawApiFact(ref['path'], ref['status_code'], (api / 'merge_ref.json').read_bytes(),
                                            stamp, ref['complete'], ref['response_headers']), REPO, pr_number)
        listing = load(evidence / 'artifacts.json')
        assert listing['total_count'] == len(listing['artifacts']) == 3
        # API and original-attack collector independently retained the same completed inventory.
        assert listing == load(api / 'artifacts.json')
        for meta in listing['artifacts']:
            raw = (evidence / f'{meta["id"]}.zip').read_bytes()
            assert sha(raw) == meta['digest'].removeprefix('sha256:') and len(raw) == meta['size_in_bytes']
            assert meta['workflow_run']['id'] == run_id and meta['workflow_run']['head_sha'] == pr['head']['sha']
            extracted = archive(raw)
            for name, member in extracted.files.items():
                assert member == (evidence / f'{meta["id"]}-members' / name).read_bytes()
        artifact = (evidence / f'{artifact_id}.zip').read_bytes()
        members = archive(artifact).files
        receipt, junit = json.loads(members['receipt.json']), members['junit.xml']
        assert receipt['producer']['workflow_sha'] == PRODUCT and receipt['producer']['job_id'] == job_id
        assert receipt['producer']['run_id'] == run_id and receipt['producer']['attempt'] == 1
        assert receipt['source']['head_sha'] == receipt['source']['checked_out_sha'] == pr['head']['sha']
        discovery = load(evidence / f'{artifact_id}-attestation-capture.json')
        assert discovery['next_cursor'] is None and len(discovery['bundles']) == 1
        bm = discovery['bundles'][0]
        compressed = (evidence / bm['body_file']).read_bytes()
        assert sha(compressed) == bm['body_sha256'] and bm['response']['status_code'] == 200 and bm['response']['complete']
        bundle = decode_bundle_body(compressed, bm['response']['response_headers'].get('content-type'))
        expected = {'repository_id': repo['id'], 'repository_full_name': REPO, 'certificate_source_sha': event_sha,
            'certificate_event': 'pull_request', 'run_id': run_id, 'run_attempt': 1,
            'producer_repository_full_name': producer_repo['full_name'], 'producer_path': receipt['producer']['workflow_path'],
            'producer_sha': PRODUCT, 'job_id': job_id, 'check_run_id': check['id'], 'artifact_id': artifact_id,
            'artifact_sha256': sha(artifact), 'receipt_sha256': sha(members['receipt.json']), 'junit_sha256': sha(junit)}
        name = f'delivery-review-{run_id}-1-{job_id}'
        matches = [r for r in listing['artifacts'] if r['name'] == name]
        detail = {'label': label, 'run_id': run_id, 'job_id': job_id, 'matched_name_ids': [x['id'] for x in matches]}
        if label == 'replacement':
            proof = evidence / '13487183331-members'
            old, new = load(proof / 'original-metadata.json'), load(proof / 'replacement-metadata.json')
            assert old['id'] == 13486744886 and new['id'] == artifact_id and old['name'] == new['name'] == name
            assert (proof / 'original.zip').read_bytes() == (proof / 'replacement.zip').read_bytes() == artifact
            assert (proof / 'original-bundle-0.json').read_bytes() == compressed
            assert len(matches) == 1 and matches[0]['id'] == artifact_id
            deletion = next(x for x in load(proof / 'requests-delete.json') if x['label'] == 'delete-original')
            assert deletion['method'] == 'DELETE' and deletion['status'] == 204
            assert deletion['path'] == f'/repos/{REPO}/actions/artifacts/{old["id"]}'
            old_expected = deepcopy(expected); old_expected['artifact_id'] = old['id']
            verify('deleted-original-identity', artifact, bundle, old_expected, True)
            verify('replacement-new-identity', artifact, bundle, expected, False)
            detail.update({'old_id': old['id'], 'new_id': new['id'], 'same_zip_bytes': True,
                           'zip_sha256': sha(artifact), 'deletion_observation': deletion,
                           'historical_original_signature_is_not_current_selection_credit': True})
        else:
            assert {x['id'] for x in matches} == {13488020622, 13487253094}
            assert {x['size_in_bytes'] for x in matches} == {190, 1927}
            proof = evidence / '13487178128-members'
            unavailable = load(proof / 'requests-observe-precreated.json')
            assert len(unavailable) == 1 and unavailable[0]['status'] == 404
            assert unavailable[0]['sha256'] == sha((proof / 'precreated-metadata.json').read_bytes())
            verify('ambiguous-genuine-member', artifact, bundle, expected, True)
            detail.update({'precreation_did_not_prevent_genuine_upload': True, 'required_selection_disposition': 'ambiguous; no candidate selected',
                           'immediate_precreator_404_preserved': unavailable[0], 'valid_member_signature_does_not_resolve_identity_ambiguity': True})
        for p in sorted(api.iterdir()):
            if p.name in API_NAMES: copy(p, f'runs/{run_id}/api/{p.name}')
        for p in sorted(evidence.rglob('*')):
            if not p.is_file(): continue
            if p.name.endswith(('.raw.log', '.stderr')):
                omissions.append({'source_path': p.relative_to(MAIN).as_posix(), 'sha256': sha(p.read_bytes()),
                                  'reason': 'Original public job logs stay local pending full locator review.'})
            else: copy(p, f'runs/{run_id}/evidence/' + p.relative_to(evidence).as_posix())
        product_result = MAIN / f'work/public-reference-inspection-{label}-linux-b9c1d2e-01'
        report = load(product_result / 'report.json')
        obligation = next(x for x in report['obligations'] if x['id'] == 'pytest-linux')
        assert report['ready_for_review'] is False
        assert obligation['outcome'] == ('untrusted' if label == 'replacement' else 'missing')
        detail['original_b9_product_result'] = {'report_sha256': sha((product_result / 'report.json').read_bytes()), 'obligation': obligation,
            'interpretation': 'Original b9 ambiguity label remains missing; later versioned diagnostic correction must not rewrite this historical report.'}
        for n in ('result.json', 'inspection.json', 'report.json', 'report.md', 'report.html', 'runtime.json', 'archive.json', 'public-reference-inspection.tar.gz'):
            copy(product_result / n, f'installed-product/{label}/{n}')
        assert before == tree(source)
        detail['original_tree'] = before; detail['originals_unchanged'] = True
        save(OUT / (label + '-review.json'), detail); reviews.append(detail)
    save(OUT / 'evidence-inventory.json', inventory); save(OUT / 'omissions.json', omissions)
    save(OUT / 'result.json', {'status': 'completed', 'qualification_status': 'pending', 'qualified': False, 'producer_sha': PRODUCT,
        'network': network, 'native': str(native), 'cases': results, 'reviews': reviews, 'originals_unchanged': True, 'registry_changed': False,
        'limitations': ['Historical original signatures do not restore a deleted artifact identity.',
            'An individually valid signed member cannot disambiguate duplicate mapped names.',
            'Authored lifecycle request captures are retained observations, not standalone cryptographic authentication of deletion.']})
except BaseException as exc:
    save(OUT / 'failure.json', {'type': type(exc).__name__, 'message': str(exc), 'completed_results': results})
    raise
