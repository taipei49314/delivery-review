# Producer qualification evidence for 3d3e545

This archive preserves public, first-party authored controls and independent
reviews for exact producer commit 3d3e54599066c98f52384c66953b130a01eaaff8.
The proposed admission covers only the two pinned pytest producer workflows,
literal test path `tests`, Linux x86_64 CPython 3.11.16, and pytest 8.4.2 xunit2.
Qualification receipt resources are separate from this archive to avoid circular
digests. This archive alone never grants qualification or complete-product E01.

The original seven functional controls retain native zero/all-skipped/failure/
collection-error/partial-skip outcomes. Head and merge boundary controls assert
the exact runtime, guest UID, credential absence, read-only mounts, network
failure, privilege/capability/seccomp state, cgroup limits and bounded tmpfs.
Disk exhaustion is an actual ENOSPC observation. Symlink report, abrupt exit,
output limit and timeout reach isolated execution and refuse a signed receipt.
Their closed diagnostic is retained; no more precise internal error is inferred.

PR13 failed source acquisition before exercising forgery. PR26 is a separate
successful attempt with identical committed fixture bytes; its raw workflow
command/private-receipt/background-writer markers did not reach host logs or
signed receipt/JUnit. Both attempts remain in the archive. Hosted signed receipt
creation is gated by reviewed producer stop/cleanup and guest GID checks; there
is no separately retained hosted Docker inspection transcript. These are
source-enforced gates supported by actual signed execution, not direct retained
post-cleanup measurements. The host kernel, Docker daemon, image, GitHub and
pinned actions remain trusted components.

Actual precreation produced TWO artifacts with the same mapped name. Genuine
upload was not prevented. Selection must refuse the complete ambiguous list;
an individually valid genuine signature cannot choose a candidate. Actual
replacement preserved the original, deleted only that control run's artifact,
and reuploaded byte-identical ZIP bytes under a new artifact ID. Official gh
cryptography succeeds but signed artifact-identity checks reject the new ID.
Historical validation of the deleted original cannot restore current credit.

Independent cryptography uses official pinned gh 2.98.0 and saved trusted root
under real network namespaces (loopback only, empty routes, ENETUNREACH probe).
Raw inputs/outputs, native exits and adapter results remain separate. Seventeen
earlier identity-control expectations, eleven signed-control verifications and
three lifecycle checks are retained. One earlier digest guard intentionally did
not invoke gh. Failed harness attempts are preserved and labelled, not passes.

The installed b9 full-product attacker reports remain original: replacement is
untrusted; duplicate-name inventory is retained but its old report label is
generic missing. A later explicit execution-plan version improves that label;
historical reports must retain their original interpretation.

All project inputs were inspected as data by this independent review. Public
job logs stay local pending a separate full locator/credential review; their
hashes and omissions remain recorded. Private EC and private Pinwash inspection
data are excluded. Discovery bodies with ephemeral storage credentials were
never retained, only their hashes/sizes and original bundle bytes. Some bundles
have a .json suffix but original application/x-snappy bytes; use recorded media
type and deterministic decoder version. No original bytes were redacted.

The byte inventory excludes itself. Pattern screening recursively inspects
bounded ZIP/tar contents and reports no matching token, credential locator or
private-evidence markers; it is an additional check, not an absence guarantee.
Authored controls establish these stated boundaries, not general test quality,
resistance to malicious kernel/daemon/actions, or arbitrary producer workflows.
